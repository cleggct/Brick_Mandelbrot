module Mandelbrot where

iterateVal :: Float -> Float -> Float -> Float -> Int -> Int -> Int
iterateVal x0 y0 x y n lim = if ((x*x + y*y <= 4) && (n < lim))
                                then iterateVal x0 y0 (x*x - y*y + x0) (2*x*y + y0) (n+1) lim
                                else n
                        
data View = View
    { centerX :: Int,
      centerY :: Int,
      zoomLvl   :: Float} deriving (Show)
     
data Direction
    = North
    | South
    | East
    | West
    deriving (Eq, Show)
     
move :: Direction -> Int -> View -> View
move North a (View {centerX = x, centerY = y, zoomLvl = z}) = View { centerX = x, centerY = y - a, zoomLvl = z}
move South a (View {centerX = x, centerY = y, zoomLvl = z}) = View { centerX = x, centerY = y + a, zoomLvl = z}
move West a (View {centerX = x, centerY = y, zoomLvl = z}) = View { centerX = x - a, centerY = y, zoomLvl = z}
move East a (View {centerX = x, centerY = y, zoomLvl = z}) = View { centerX = x + a, centerY = y, zoomLvl = z}

zoomView :: Float -> View -> View
zoomView z' (View {centerX = x, centerY = y, zoomLvl = z}) = View { centerX = x, centerY = y, zoomLvl = z*z' }

initView :: View
initView = View {centerX = 0, centerY = 0, zoomLvl = 1.0}
